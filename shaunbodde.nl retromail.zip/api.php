<?php
declare(strict_types=1);

ini_set('session.use_strict_mode', '1');
session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
session_start();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

const DOMAIN = 'shaunbodde.nl';
const DIVIDER = '----------------------------------------------------------------';
$dataRoot = __DIR__ . DIRECTORY_SEPARATOR . 'MailServerData';

function respond(array $data, int $status = 200): never
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function request_data(): array
{
    $decoded = json_decode(file_get_contents('php://input') ?: '', true);
    return is_array($decoded) ? $decoded : [];
}

function valid_username(mixed $username): bool
{
    return is_string($username) && preg_match('/^[a-z0-9._-]{2,30}$/', $username) === 1;
}

function account_path(string $username): string
{
    global $dataRoot;
    return $dataRoot . DIRECTORY_SEPARATOR . 'Accounts' . DIRECTORY_SEPARATOR . $username . '.dat';
}

function read_account(string $username): ?array
{
    $path = account_path($username);
    if (!is_file($path)) {
        return null;
    }
    $account = [];
    foreach (file($path, FILE_IGNORE_NEW_LINES) ?: [] as $line) {
        $parts = explode('=', $line, 2);
        if (count($parts) === 2) {
            $account[$parts[0]] = $parts[1];
        }
    }
    return $account;
}

function write_file_atomically(string $path, string $content): void
{
    $temporary = $path . '.' . bin2hex(random_bytes(5)) . '.tmp';
    if (file_put_contents($temporary, $content, LOCK_EX) === false || !rename($temporary, $path)) {
        @unlink($temporary);
        respond(['error' => 'Bestand kon niet worden opgeslagen. Controleer de schrijfrechten van MailServerData.'], 500);
    }
}

function ensure_mailboxes(string $username): void
{
    global $dataRoot;
    foreach (['Drafts', 'Inbox', 'Sent', 'Trash'] as $folder) {
        $path = $dataRoot . DIRECTORY_SEPARATOR . 'Mail' . DIRECTORY_SEPARATOR . $username . DIRECTORY_SEPARATOR . $folder;
        if (!is_dir($path) && !mkdir($path, 0775, true) && !is_dir($path)) {
            respond(['error' => 'Mailboxmap kon niet worden aangemaakt. Controleer de schrijfrechten van MailServerData.'], 500);
        }
    }
}

function copy_tree(string $source, string $destination): void
{
    if (!is_dir($source)) {
        return;
    }
    if (!is_dir($destination) && !mkdir($destination, 0775, true) && !is_dir($destination)) {
        respond(['error' => 'Back-upmap kon niet worden aangemaakt.'], 500);
    }
    $iterator = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($source, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::SELF_FIRST
    );
    foreach ($iterator as $item) {
        $target = $destination . DIRECTORY_SEPARATOR . $iterator->getSubPathName();
        if ($item->isDir()) {
            if (!is_dir($target) && !mkdir($target, 0775, true) && !is_dir($target)) {
                respond(['error' => 'Back-upmap kon niet worden aangemaakt.'], 500);
            }
        } elseif (!copy($item->getPathname(), $target)) {
            respond(['error' => 'Back-upbestand kon niet worden gekopieerd.'], 500);
        }
    }
}

function server_date(): string
{
    $now = new DateTimeImmutable('now');
    $days = ['Mon' => 'ma', 'Tue' => 'di', 'Wed' => 'wo', 'Thu' => 'do', 'Fri' => 'vr', 'Sat' => 'za', 'Sun' => 'zo'];
    return $days[$now->format('D')] . $now->format('d-m-Y_H-i-s,') . substr($now->format('u'), 0, 2);
}

function account_created_date(): string
{
    $now = new DateTimeImmutable('now');
    $days = ['Mon' => 'ma', 'Tue' => 'di', 'Wed' => 'wo', 'Thu' => 'do', 'Fri' => 'vr', 'Sat' => 'za', 'Sun' => 'zo'];
    return $days[$now->format('D')] . ' ' . $now->format('d-m-Y H:i:s,') . substr($now->format('u'), 0, 2);
}

function create_backup(): void
{
    global $dataRoot;
    $backupRoot = $dataRoot . DIRECTORY_SEPARATOR . 'Backups';
    if (!is_dir($backupRoot) && !mkdir($backupRoot, 0775, true) && !is_dir($backupRoot)) {
        respond(['error' => 'Back-upmap kon niet worden aangemaakt.'], 500);
    }
    $name = 'Backup_' . server_date();
    $backupPath = $backupRoot . DIRECTORY_SEPARATOR . $name;
    $suffix = 1;
    while (file_exists($backupPath)) {
        $backupPath = $backupRoot . DIRECTORY_SEPARATOR . $name . '_' . $suffix++;
    }
    if (!mkdir($backupPath, 0775, true)) {
        respond(['error' => 'Back-upmap kon niet worden aangemaakt.'], 500);
    }
    foreach (['Accounts', 'Mail'] as $folder) {
        copy_tree($dataRoot . DIRECTORY_SEPARATOR . $folder, $backupPath . DIRECTORY_SEPARATOR . $folder);
    }
}

function mailbox_path(string $username, string $folder): string
{
    global $dataRoot;
    return $dataRoot . DIRECTORY_SEPARATOR . 'Mail' . DIRECTORY_SEPARATOR . $username . DIRECTORY_SEPARATOR . $folder;
}

function local_part(string $address): string
{
    $address = trim($address);
    return strtolower(str_contains($address, '@') ? (string) strstr($address, '@', true) : $address);
}

function normalized_address(string $address): string
{
    $address = trim($address);
    return str_contains($address, '@') ? $address : $address . '@' . DOMAIN;
}

function parse_eml(string $path, string $username, string $folder): ?array
{
    $raw = file_get_contents($path);
    if ($raw === false) {
        return null;
    }
    $parts = preg_split("/\r?\n\r?\n/", $raw, 2);
    $headers = [];
    foreach (preg_split('/\r?\n/', $parts[0] ?? '') ?: [] as $line) {
        $header = explode(':', $line, 2);
        if (count($header) === 2) {
            $headers[strtolower(trim($header[0]))] = trim($header[1]);
        }
    }
    $body = '';
    if (preg_match('/\R-{8,}\RMessage\R-{8,}\R(.*?)\R-{8,}\RDelivered by Shaun.*$/s', $raw, $match) === 1) {
        $body = rtrim($match[1], "\r\n");
    }
    $from = normalized_address($headers['from'] ?? '');
    $to = normalized_address($headers['to'] ?? '');
    $date = null;
    if (preg_match('/(\d{2})-(\d{2})-(\d{4}) (\d{2}:\d{2}:\d{2})/', $headers['date'] ?? '', $dateMatch) === 1) {
        $parsedDate = DateTimeImmutable::createFromFormat('d-m-Y H:i:s', $dateMatch[1] . '-' . $dateMatch[2] . '-' . $dateMatch[3] . ' ' . $dateMatch[4]);
        $date = $parsedDate ? $parsedDate->format(DateTimeInterface::ATOM) : null;
    }
    $owner = read_account($username);
    $isSent = $folder === 'Sent' || ($folder === 'Trash' && strcasecmp($from, $owner['EMAIL'] ?? '') === 0);
    return [
        'id' => basename($path) === '.eml' ? '__dotfile__' : pathinfo($path, PATHINFO_FILENAME),
        'messageId' => $headers['message-id'] ?? '',
        'folder' => $folder,
        'type' => $isSent ? 'sent' : 'received',
        'sender' => local_part($from),
        'receiver' => local_part($to),
        'from' => $from,
        'to' => $to,
        'cc' => $headers['cc'] ?? '',
        'bcc' => $headers['bcc'] ?? '',
        'subject' => $headers['subject'] ?? '(Geen onderwerp)',
        'body' => $body,
        'date' => $date ?? date(DateTimeInterface::ATOM, filemtime($path) ?: time()),
        'read' => strtoupper($headers['status'] ?? '') !== 'UNREAD',
    ];
}

function list_messages(string $username, string $folder): array
{
    $folders = match ($folder) {
        'inbox' => ['Inbox'],
        'sent' => ['Sent'],
        'trash' => ['Trash'],
        'all' => ['Inbox', 'Sent'],
        default => [],
    };
    $messages = [];
    foreach ($folders as $mailFolder) {
        $path = mailbox_path($username, $mailFolder);
        foreach (scandir($path) ?: [] as $filename) {
            $file = $path . DIRECTORY_SEPARATOR . $filename;
            if (!is_file($file) || strtolower(substr($filename, -4)) !== '.eml') {
                continue;
            }
            $message = parse_eml($file, $username, $mailFolder);
            if ($message !== null) {
                $messages[] = $message;
            }
        }
    }
    usort($messages, static fn(array $a, array $b): int => strcmp($b['date'], $a['date']));
    return $messages;
}

function safe_mail_id(mixed $id): ?string
{
    return is_string($id) && preg_match('/^[A-Za-z0-9_-]{1,128}$/', $id) === 1 ? $id : null;
}

function message_path(string $username, string $folder, string $mailId): string
{
    $filename = $mailId === '__dotfile__' ? '.eml' : $mailId . '.eml';
    return mailbox_path($username, $folder) . DIRECTORY_SEPARATOR . $filename;
}

function create_eml(array $message, string $messageId, string $status = 'UNREAD'): string
{
    $date = new DateTimeImmutable($message['date'] ?? 'now');
    $days = ['Mon' => 'ma', 'Tue' => 'di', 'Wed' => 'wo', 'Thu' => 'do', 'Fri' => 'vr', 'Sat' => 'za', 'Sun' => 'zo'];
    $dateText = $days[$date->format('D')] . ' ' . $date->format('d-m-Y H:i:s,') . substr($date->format('u'), 0, 2);
    $headers = [
        'From: ' . normalized_address((string) ($message['from'] ?? '')),
        'To: ' . normalized_address((string) ($message['to'] ?? '')),
        'Cc: ' . (string) ($message['cc'] ?? ''),
        'Bcc: ' . (string) ($message['bcc'] ?? ''),
        'Subject: ' . str_replace(["\r", "\n"], '', (string) ($message['subject'] ?? '(Geen onderwerp)')),
        'Date: ' . $dateText,
        'Message-ID: ' . $messageId,
        'Status: ' . $status,
        '', DIVIDER, 'Message', DIVIDER,
    ];
    $body = str_replace(["\r\n", "\r"], "\n", (string) ($message['body'] ?? ''));
    return implode("\r\n", $headers) . "\r\n" . str_replace("\n", "\r\n", $body) . "\r\n" . DIVIDER . "\r\nDelivered by Shaun Bodde Mail Server v3.0\r\n" . DIVIDER . "\r\n";
}

function save_message(string $username, string $folder, array $message, string $messageId, string $status = 'UNREAD'): string
{
    ensure_mailboxes($username);
    $directory = mailbox_path($username, $folder);
    do {
        $filename = (string) random_int(100000000, 999999999) . '.eml';
        $path = $directory . DIRECTORY_SEPARATOR . $filename;
    } while (file_exists($path));
    write_file_atomically($path, create_eml($message, $messageId, $status));
    return pathinfo($path, PATHINFO_FILENAME);
}

function require_auth(): string
{
    $username = $_SESSION['username'] ?? null;
    if (!valid_username($username) || read_account($username) === null) {
        respond(['error' => 'Log opnieuw in.'], 401);
    }
    return $username;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(['error' => 'Gebruik POST voor deze API.'], 405);
}

$input = request_data();
$action = $input['action'] ?? '';

if ($action === 'session') {
    $username = $_SESSION['username'] ?? null;
    $account = valid_username($username) ? read_account($username) : null;
    respond(['user' => $account ? ['username' => $username, 'email' => $account['EMAIL'] ?? ($username . '@' . DOMAIN)] : null]);
}

if ($action === 'register') {
    $username = strtolower((string) ($input['username'] ?? ''));
    $password = (string) ($input['password'] ?? '');
    if (!valid_username($username) || strlen($password) < 4) {
        respond(['error' => 'Ongeldige gebruikersnaam of wachtwoord.'], 400);
    }
    if (read_account($username) !== null) {
        respond(['error' => 'Dit account bestaat al.', 'code' => 'account_exists'], 409);
    }
    create_backup();
    $email = $username . '@' . DOMAIN;
    $record = "USERNAME={$username}\r\nEMAIL={$email}\r\nPASSWORD={$password}\r\nCREATED=" . account_created_date() . "\r\n";
    write_file_atomically(account_path($username), $record);
    ensure_mailboxes($username);
    respond(['ok' => true, 'email' => $email]);
}

if ($action === 'login') {
    $username = strtolower((string) ($input['username'] ?? ''));
    $password = (string) ($input['password'] ?? '');
    if (!valid_username($username) || read_account($username) === null) {
        respond(['error' => 'Account bestaat niet.', 'code' => 'not_found'], 404);
    }
    $account = read_account($username) ?? [];
    if (!isset($account['PASSWORD']) || !hash_equals($account['PASSWORD'], $password)) {
        respond(['error' => 'Wachtwoord is onjuist.', 'code' => 'invalid_password'], 401);
    }
    session_regenerate_id(true);
    $_SESSION['username'] = $username;
    ensure_mailboxes($username);
    respond(['ok' => true, 'user' => ['username' => $username, 'email' => $account['EMAIL'] ?? ($username . '@' . DOMAIN)]]);
}

if ($action === 'logout') {
    $_SESSION = [];
    session_destroy();
    respond(['ok' => true]);
}

$username = require_auth();
$account = read_account($username) ?? [];
$currentEmail = $account['EMAIL'] ?? ($username . '@' . DOMAIN);

if ($action === 'messages') {
    $folder = (string) ($input['folder'] ?? 'inbox');
    if (!in_array($folder, ['inbox', 'sent', 'all', 'trash', 'spam'], true)) {
        respond(['error' => 'Onbekende map.'], 400);
    }
    respond(['messages' => list_messages($username, $folder)]);
}

if ($action === 'send') {
    $to = trim((string) ($input['to'] ?? ''));
    $cc = trim((string) ($input['cc'] ?? ''));
    $bcc = trim((string) ($input['bcc'] ?? ''));
    $subject = trim((string) ($input['subject'] ?? '')) ?: '(Geen onderwerp)';
    $body = (string) ($input['body'] ?? '');
    $split = static fn(string $addresses): array => array_values(array_filter(array_map('trim', preg_split('/[;,]+/', strtolower($addresses)) ?: [])));
    $toList = $split($to);
    if (!$toList) {
        respond(['error' => 'Vul een ontvanger in.'], 400);
    }
    $recipients = array_values(array_unique(array_merge($toList, $split($cc), $split($bcc))));
    foreach ($recipients as $address) {
        $recipient = local_part($address);
        if (!str_ends_with($address, '@' . DOMAIN) || !valid_username($recipient) || read_account($recipient) === null) {
            respond(['error' => 'Ontvanger bestaat niet: ' . $address], 400);
        }
    }
    create_backup();
    $messageId = '<' . bin2hex(random_bytes(12)) . '@' . DOMAIN . '>';
    $message = ['from' => $currentEmail, 'to' => implode(', ', $toList), 'cc' => implode(', ', $split($cc)), 'bcc' => '', 'subject' => $subject, 'body' => $body, 'date' => (new DateTimeImmutable('now'))->format('Y-m-d H:i:s.uP')];
    foreach ($recipients as $address) {
        save_message(local_part($address), 'Inbox', $message, $messageId, 'UNREAD');
    }
    $message['bcc'] = implode(', ', $split($bcc));
    save_message($username, 'Sent', $message, $messageId, 'READ');
    respond(['ok' => true]);
}

if ($action === 'mark_read' || $action === 'trash') {
    $mailId = safe_mail_id($input['id'] ?? null);
    $folder = (string) ($input['folder'] ?? 'Inbox');
    if ($mailId === null || !in_array($folder, ['Inbox', 'Sent', 'Trash'], true)) {
        respond(['error' => 'Ongeldig bericht.'], 400);
    }
    $source = message_path($username, $folder, $mailId);
    if (!is_file($source)) {
        respond(['error' => 'Bericht niet gevonden.'], 404);
    }
    if ($action === 'trash') {
        create_backup();
        if ($folder === 'Trash') {
            if (!unlink($source)) {
                respond(['error' => 'Bericht kon niet permanent worden verwijderd.'], 500);
            }
        } else {
            $destination = mailbox_path($username, 'Trash') . DIRECTORY_SEPARATOR . ($mailId === '__dotfile__' ? random_int(100000000, 999999999) : $mailId) . '.eml';
            if (file_exists($destination)) {
                $destination = mailbox_path($username, 'Trash') . DIRECTORY_SEPARATOR . random_int(100000000, 999999999) . '.eml';
            }
            if (!rename($source, $destination)) {
                respond(['error' => 'Bericht kon niet naar de prullenbak worden verplaatst.'], 500);
            }
        }
        respond(['ok' => true]);
    }
    $raw = file_get_contents($source);
    if ($raw === false) {
        respond(['error' => 'Bericht kon niet worden gelezen.'], 500);
    }
    $raw = preg_match('/^Status:.*$/mi', $raw) === 1
        ? (preg_replace('/^Status:.*$/mi', 'Status: READ', $raw, 1) ?? $raw)
        : (preg_replace('/\R\R/', "\r\nStatus: READ\r\n\r\n", $raw, 1) ?? $raw);
    create_backup();
    write_file_atomically($source, $raw);
    respond(['ok' => true]);
}

if ($action === 'import_legacy') {
    $mails = $input['messages'] ?? [];
    if (!is_array($mails)) {
        respond(['error' => 'Ongeldige importdata.'], 400);
    }
    $ownedMessages = [];
    foreach ($mails as $mail) {
        if (!is_array($mail)) {
            continue;
        }
        $isSent = ($mail['type'] ?? '') === 'sent' && strtolower((string) ($mail['sender'] ?? '')) === $username;
        $isReceived = ($mail['type'] ?? '') === 'received' && strtolower((string) ($mail['receiver'] ?? '')) === $username;
        if ($isSent || $isReceived) {
            $ownedMessages[] = [$mail, $isSent ? 'Sent' : 'Inbox'];
        }
    }
    if ($ownedMessages) {
        create_backup();
    }
    $added = 0;
    foreach ($ownedMessages as [$mail, $folder]) {
        $legacyId = preg_replace('/[^A-Za-z0-9_-]/', '', (string) ($mail['id'] ?? '')) ?: bin2hex(random_bytes(8));
        $messageId = '<webmail-' . $legacyId . '@' . DOMAIN . '>';
        $duplicate = false;
        foreach (scandir(mailbox_path($username, $folder)) ?: [] as $filename) {
            $file = mailbox_path($username, $folder) . DIRECTORY_SEPARATOR . $filename;
            if (!is_file($file) || strtolower(substr($filename, -4)) !== '.eml') {
                continue;
            }
            if (str_contains((string) file_get_contents($file), 'Message-ID: ' . $messageId)) {
                $duplicate = true;
                break;
            }
        }
        if ($duplicate) {
            continue;
        }
        $message = [
            'from' => (string) ($mail['from'] ?? ''),
            'to' => (string) ($mail['to'] ?? ''),
            'cc' => (string) ($mail['cc'] ?? ''),
            'bcc' => $folder === 'Sent' ? (string) ($mail['bcc'] ?? '') : '',
            'subject' => (string) ($mail['subject'] ?? '(Geen onderwerp)'),
            'body' => (string) ($mail['body'] ?? ''),
            'date' => (string) ($mail['date'] ?? date(DateTimeInterface::ATOM)),
        ];
        save_message($username, $folder, $message, $messageId, !empty($mail['read']) ? 'READ' : 'UNREAD');
        $added++;
    }
    respond(['ok' => true, 'imported' => $added]);
}

respond(['error' => 'Onbekende actie.'], 404);